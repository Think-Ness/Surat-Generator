// src/pages/Mailing.jsx
import { useState, useEffect } from 'react';
import { api } from '../lib/api';
import { buildSuratHTML, printSurat, exportPDF, exportWord,
         formatTanggalIndo, toast } from '../lib/utils';

export default function Mailing({ seting, initBatch }) {
  const [allSurat,  setAllSurat]  = useState([]);
  const [batches,   setBatches]   = useState([]);
  const [selBatch,  setSelBatch]  = useState(initBatch || null);
  const [rows,      setRows]      = useState([]);
  const [barang,    setBarang]    = useState([]);
  const [loading,   setLoading]   = useState(false);
  const [deleting,  setDeleting]  = useState(false);

  // Load semua surat untuk buat daftar batch
  useEffect(() => {
    setLoading(true);
    api.getSurat()
      .then(r => {
        const data = r.data || [];
        setAllSurat(data);
        // Kelompokkan per batch
        const bMap = {};
        data.forEach(d => {
          if (!bMap[d.ID_Batch]) {
            bMap[d.ID_Batch] = {
              id: d.ID_Batch,
              jenisSurat:   d.Jenis_Surat,
              jenisMailing: d.Jenis_Mailing,
              tanggal:      d.Tanggal,
              acara:        d.Acara,
              count:        0,
            };
          }
          bMap[d.ID_Batch].count++;
        });
        const bl = Object.values(bMap).sort((a,b) => b.id - a.id);
        setBatches(bl);
        if (initBatch) {
          setSelBatch(initBatch);
        } else if (bl.length > 0 && !selBatch) {
          setSelBatch(bl[0].id);
        }
      })
      .catch(() => toast('Gagal memuat mailing','error'))
      .finally(() => setLoading(false));
  }, []);

  // Load rows + barang ketika batch berubah
  useEffect(() => {
    if (!selBatch) return;
    const filtered = allSurat.filter(d => Number(d.ID_Batch) === Number(selBatch));
    setRows(filtered);

    // Ambil barang jika ada Peminjaman
    const isPinjam = filtered[0]?.Jenis_Surat === 'Peminjaman';
    if (isPinjam && filtered[0]?.No_Surat) {
      api.getBarang(filtered[0].No_Surat)
         .then(r => setBarang(r.data || []))
         .catch(() => {});
    } else {
      setBarang([]);
    }
  }, [selBatch, allSurat]);

  const selBatchInfo = batches.find(b => Number(b.id) === Number(selBatch));

  const handleGenerate = (mode) => {
    if (!rows.length) { toast('Tidak ada data','error'); return; }
    const setingArr = seting ? Object.entries(seting).map(([k,v])=>({...v,kode:k})) : [];

    if (rows[0]?.Jenis_Mailing === 'Sekaligus') {
      // Satu dokumen untuk semua
      const html     = buildSuratHTML(rows, rows[0].Jenis_Surat, 'Sekaligus', seting, barang);
      const filename = `${rows[0].Jenis_Surat}_Sekaligus_Batch${selBatch}`;
      if (mode==='print') printSurat(html);
      if (mode==='pdf')   exportPDF(html, filename);
      if (mode==='word')  exportWord(html, filename);
    } else {
      // Satu dokumen per orang
      rows.forEach(r => {
        const html     = buildSuratHTML([r], r.Jenis_Surat, 'Perseorangan', seting, barang);
        const filename = `${r.Jenis_Surat}_${r.Nama}_${r.No_Surat}`;
        if (mode==='print') printSurat(html);
        if (mode==='pdf')   exportPDF(html, filename);
        if (mode==='word')  exportWord(html, filename);
      });
    }
    toast(`${mode==='print'?'Mencetak':mode==='pdf'?'Export PDF':'Export Word'} berhasil`, 'success');
  };

  const handleDeleteBatch = async () => {
    if (!selBatch) return;
    if (!window.confirm('Hapus seluruh data batch ini? Tidak dapat dibatalkan.')) return;
    setDeleting(true);
    try {
      await api.deleteBatch(selBatch);
      toast('Batch berhasil dihapus','success');
      // Reload
      const r = await api.getSurat();
      const data = r.data || [];
      setAllSurat(data);
      const bMap = {};
      data.forEach(d => {
        if (!bMap[d.ID_Batch]) bMap[d.ID_Batch] = { id:d.ID_Batch, jenisSurat:d.Jenis_Surat,
          jenisMailing:d.Jenis_Mailing, tanggal:d.Tanggal, acara:d.Acara, count:0 };
        bMap[d.ID_Batch].count++;
      });
      const bl = Object.values(bMap).sort((a,b)=>b.id-a.id);
      setBatches(bl);
      setSelBatch(bl[0]?.id || null);
    } catch(e) {
      toast('Gagal hapus: '+e.message,'error');
    } finally {
      setDeleting(false);
    }
  };

  const BADGE = {
    'Perizinan':  'badge-amber',
    'Undangan':   'badge-blue',
    'Peminjaman': 'badge-green',
  };

  return (
    <div className="fade-in" style={{ display:'grid', gridTemplateColumns:'260px 1fr', gap:16 }}>

      {/* ── Panel kiri: daftar batch ── */}
      <div>
        <div style={{ fontWeight:700, fontSize:12, letterSpacing:.5, textTransform:'uppercase',
                      color:'var(--text-muted)', marginBottom:10 }}>
          Riwayat Mailing
        </div>
        {loading ? (
          <div style={{ padding:20, textAlign:'center', opacity:.5, fontSize:13 }}>Memuat...</div>
        ) : batches.length === 0 ? (
          <div style={{ padding:20, textAlign:'center', opacity:.5, fontSize:13 }}>
            Belum ada mailing
          </div>
        ) : batches.map(b => (
          <div key={b.id}
            onClick={() => setSelBatch(b.id)}
            style={{
              padding:'10px 14px', borderRadius:8, cursor:'pointer', marginBottom:6,
              border:`1px solid ${Number(selBatch)===Number(b.id) ? 'var(--accent)' : 'var(--border)'}`,
              background: Number(selBatch)===Number(b.id) ? 'var(--accent-soft)' : 'var(--card)',
              transition:'all .15s',
            }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:4 }}>
              <span className={`badge ${BADGE[b.jenisSurat]||'badge-blue'}`}>{b.jenisSurat}</span>
              <span style={{ fontSize:11, opacity:.5 }}>#{b.id}</span>
            </div>
            <div style={{ fontSize:12, fontWeight:600, marginBottom:2 }}>{b.acara || '-'}</div>
            <div style={{ fontSize:11, opacity:.6 }}>
              {formatTanggalIndo(b.tanggal)} · {b.count} orang · {b.jenisMailing}
            </div>
          </div>
        ))}
      </div>

      {/* ── Panel kanan: detail batch ── */}
      <div>
        {!selBatch || !selBatchInfo ? (
          <div className="card" style={{ padding:60, textAlign:'center', opacity:.5 }}>
            Pilih batch dari daftar kiri
          </div>
        ) : (
          <>
            {/* Info batch */}
            <div className="card" style={{ marginBottom:14 }}>
              <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', flexWrap:'wrap', gap:12 }}>
                <div>
                  <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
                    <span className={`badge ${BADGE[selBatchInfo.jenisSurat]||'badge-blue'}`} style={{ fontSize:13 }}>
                      {selBatchInfo.jenisSurat}
                    </span>
                    <span className="badge badge-blue">{selBatchInfo.jenisMailing}</span>
                    <span style={{ fontSize:12, opacity:.5 }}>Batch #{selBatch}</span>
                  </div>
                  <div style={{ fontWeight:700, fontSize:16, marginBottom:2 }}>
                    {rows[0]?.Acara || '-'}
                  </div>
                  <div style={{ fontSize:13, opacity:.6 }}>
                    {rows[0]?.Hari}, {formatTanggalIndo(rows[0]?.Tanggal)} · {rows[0]?.Waktu} · {rows[0]?.Tempat}
                  </div>
                </div>
                <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                  <button className="btn btn-ghost" style={{ fontSize:12 }}
                    onClick={() => handleGenerate('print')}>🖨 Print</button>
                  <button className="btn btn-secondary" style={{ fontSize:12 }}
                    onClick={() => handleGenerate('pdf')}>📄 PDF</button>
                  <button className="btn btn-success" style={{ fontSize:12 }}
                    onClick={() => handleGenerate('word')}>📝 Word</button>
                  <button className="btn btn-danger" style={{ fontSize:12 }}
                    onClick={handleDeleteBatch} disabled={deleting}>
                    {deleting ? '⏳' : '🗑 Hapus'}
                  </button>
                </div>
              </div>
            </div>

            {/* Tabel nama */}
            <div className="card" style={{ marginBottom:14 }}>
              <div className="section-title">Daftar Nama ({rows.length} orang)</div>
              <div style={{ overflowX:'auto' }}>
                <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
                  <thead>
                    <tr style={{ background:'var(--bg)' }}>
                      {['No.','No. Surat','Nama','Keterangan','Kamar/Bagian','Prodi','Semester'].map(h => (
                        <th key={h} style={{ padding:'8px 10px', textAlign:'left', fontSize:12,
                                             fontWeight:600, color:'var(--text-muted)',
                                             borderBottom:'1px solid var(--border)' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r, i) => (
                      <tr key={r.ID_Surat} style={{ borderBottom:'1px solid var(--border)' }}>
                        <td style={{ padding:'8px 10px', opacity:.5 }}>{i+1}</td>
                        <td style={{ padding:'8px 10px' }}>{r.No_Surat}</td>
                        <td style={{ padding:'8px 10px', fontWeight:600 }}>{r.Nama}</td>
                        <td style={{ padding:'8px 10px', opacity:.7 }}>{r.Ket}</td>
                        <td style={{ padding:'8px 10px', opacity:.7 }}>{r.Kamar_Bagian}</td>
                        <td style={{ padding:'8px 10px', opacity:.7 }}>{r.Prodi}</td>
                        <td style={{ padding:'8px 10px', opacity:.7 }}>{r.Semester}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Tabel barang jika peminjaman */}
            {selBatchInfo.jenisSurat === 'Peminjaman' && (
              <div className="card">
                <div className="section-title">Daftar Barang Pinjaman</div>
                {barang.length === 0 ? (
                  <div style={{ opacity:.5, fontSize:13, padding:'12px 0' }}>
                    Tidak ada data barang
                  </div>
                ) : (
                  <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
                    <thead>
                      <tr style={{ background:'var(--bg)' }}>
                        {['No.','Nama Barang','Jumlah','Satuan','Keterangan'].map(h => (
                          <th key={h} style={{ padding:'8px 10px', textAlign:'left', fontSize:12,
                                               fontWeight:600, color:'var(--text-muted)',
                                               borderBottom:'1px solid var(--border)' }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {barang.map((b, i) => (
                        <tr key={b.ID_Peminjaman} style={{ borderBottom:'1px solid var(--border)' }}>
                          <td style={{ padding:'8px 10px', opacity:.5 }}>{i+1}</td>
                          <td style={{ padding:'8px 10px', fontWeight:600 }}>{b.Nama_Barang}</td>
                          <td style={{ padding:'8px 10px' }}>{b.Jumlah_Barang}</td>
                          <td style={{ padding:'8px 10px', opacity:.7 }}>{b.Satuan}</td>
                          <td style={{ padding:'8px 10px', opacity:.7 }}>{b.Keterangan}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
