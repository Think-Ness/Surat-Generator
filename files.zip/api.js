// src/lib/api.js
// Ganti SCRIPT_URL dengan URL Apps Script Anda setelah deploy

export const SCRIPT_URL = import.meta.env.VITE_SCRIPT_URL || '';

async function get(action, params = {}) {
  const url = new URL(SCRIPT_URL);
  url.searchParams.set('action', action);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const res = await fetch(url.toString());
  const json = await res.json();
  if (json.error) throw new Error(json.error);
  return json;
}

async function post(action, payload = {}) {
  const res = await fetch(SCRIPT_URL, {
    method: 'POST',
    body: JSON.stringify({ action, ...payload }),
  });
  const json = await res.json();
  if (json.error) throw new Error(json.error);
  return json;
}

export const api = {
  // Master Guru
  getGuru:        ()        => get('getGuru'),
  addGuru:        (data)    => post('addGuru', data),
  updateGuru:     (data)    => post('updateGuru', data),
  deleteGuru:     (data)    => post('deleteGuru', data),

  // Surat
  getSurat:       (batch)   => get('getSurat', batch ? { batch } : {}),
  insertSurat:    (rows)    => post('insertSurat', { rows }),
  deleteBatch:    (batch)   => post('deleteBatch', { batch }),
  getNextNoSurat: ()        => get('getNextNoSurat'),
  getNextBatch:   ()        => get('getNextBatch'),

  // Barang
  getBarang:      (noSurat) => get('getBarang', { noSurat }),
  insertBarang:   (items)   => post('insertBarang', { items }),
  deleteBarang:   (id)      => post('deleteBarang', { ID_Peminjaman: id }),

  // Seting
  getSeting:      ()        => get('getSeting'),
  saveSeting:     (items)   => post('saveSeting', { items }),
};
