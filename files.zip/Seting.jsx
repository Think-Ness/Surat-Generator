// src/pages/Seting.jsx
import { useState, useEffect } from 'react';
import { api } from '../lib/api';
import { toast } from '../lib/utils';

const FIELDS = [
  { kode:0, nama:'Nama Instansi',  placeholder:'Pondok Modern Darussalam Gontor' },
  { kode:1, nama:'Alamat',         placeholder:'Ponorogo, Jawa Timur' },
  { kode:2, nama:'Nama TTD',       placeholder:'KH. ...' },
  { kode:3, nama:'Jabatan TTD',    placeholder:'Direktur KMI' },
];

export default function Seting({ seting, onSave }) {
  const [form,   setForm]   = useState({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const init = {};
    FIELDS.forEach(f => {
      init[f.kode] = seting?.[f.kode]?.nilai || '';
    });
    setForm(init);
  }, [seting]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const items = FIELDS.map(f => ({
        Kode: f.kode, Nama: f.nama, Nilai: form[f.kode] || ''
      }));
      await api.saveSeting(items);
      // Update parent state
      const r = await api.getSeting();
      onSave(r.data || {});
      toast('Pengaturan disimpan','success');
    } catch(e) {
      toast('Gagal: '+e.message,'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fade-in" style={{ maxWidth:560 }}>
      <div className="card">
        <div className="section-title">Pengaturan Instansi & Kop Surat</div>
        {FIELDS.map(f => (
          <div key={f.kode} style={{ marginBottom:14 }}>
            <label>{f.nama}</label>
            <input value={form[f.kode] || ''} placeholder={f.placeholder}
              onChange={e => setForm(v => ({ ...v, [f.kode]: e.target.value }))} />
          </div>
        ))}
        <div style={{ marginTop:8, display:'flex', justifyContent:'flex-end' }}>
          <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
            {saving ? '⏳ Menyimpan...' : '💾 Simpan Pengaturan'}
          </button>
        </div>
      </div>

      <div className="card" style={{ marginTop:16 }}>
        <div className="section-title">Koneksi Google Sheets</div>
        <div style={{ fontSize:13, lineHeight:1.8, opacity:.7 }}>
          <p>URL Apps Script dikonfigurasi melalui environment variable:</p>
          <code style={{ display:'block', padding:'8px 12px', background:'var(--bg)',
                         borderRadius:6, margin:'8px 0', fontSize:12 }}>
            VITE_SCRIPT_URL=https://script.google.com/macros/s/...
          </code>
          <p>Buat file <code>.env</code> di root project, isi dengan URL Apps Script Anda.</p>
        </div>
      </div>
    </div>
  );
}
