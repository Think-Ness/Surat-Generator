// src/pages/BuatSurat.jsx
import { useState, useEffect, useCallback } from 'react';
import { api } from '../lib/api';
import { getHariIndo, toast } from '../lib/utils';
import BarangModal from '../components/BarangModal';

const JENIS_SURAT   = ['Perizinan','Undangan','Peminjaman'];
const JENIS_MAILING = ['Perseorangan','Sekaligus'];
const HARI          = ['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Ahad'];

const EMPTY_FORM = {
  jenisSurat:'Perizinan', jenisMailing:'Perseorangan',
  noSurat:'', tglHijriah:'', tglRomawi:'',
  hal:'', ket:'', hari:'', tanggal:'', tempat:'', waktu:'', acara:'',
};

export default function BuatSurat({ seting, onDone }) {
  const [form,        setForm]        = useState(EMPTY_FORM);
  const [guru,        setGuru]        = useState([]);
  const [selected,    setSelected]    = useState(new Set());
  const [search,      setSearch]      = useState('');
  const [loading,     setLoading]     = useState(false);
  const [loadingGuru, setLoadingGuru] = useState(true);
  const [showBarang,  setShowBarang]  = useState(false);
  const [noSuratBarang, setNoSuratBarang] = useState(null);

  // Load guru & next no surat
  useEffect(() => {
    setLoadingGuru(true);
    Promise.all([api.getGuru(), api.getNextNoSurat()])
      .then(([g, n]) => {
        setGuru(g.data || []);
        setForm(f => ({ ...f, noSurat: n.next }));
      })
      .catch(() => toast('Gagal memuat data guru','error'))
      .finally(() => setLoadingGuru(false));
  }, []);

  // Auto-isi hari dari tanggal
  useEffect(() => {
    if (form.tanggal) {
      setForm(f => ({ ...f, hari: getHariIndo(form.tanggal) }));
    }
  }, [form.tanggal]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const filteredGuru = guru.filter(g =>
    g.Nama?.toLowerCase().includes(search.toLowerCase()) ||
    g.Kamar_Bagian?.toLowerCase().includes(search.toLowerCase()) ||
    g.Prodi?.toLowerCase().includes(search.toLowerCase())
  );

  const toggleGuru = (id) => {
    setSelected(s => {
      const n = new Set(s);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };

  const toggleAll = () => {
    if (selected.size === filteredGuru.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(filteredGuru.map(g => g.ID_Guru)));
    }
  };

  const handleOpenBarang = () => {
    setNoSuratBarang(form.noSurat);
    setShowBarang(true);
  };

  const validate = () => {
    if (!form.jenisSurat)  { toast('Pilih jenis surat','error'); return false; }
    if (!form.jenisMailing){ toast('Pilih jenis mailing','error'); return false; }
    if (!form.hal)         { toast('Perihal harus diisi','error'); return false; }
    if (!form.tanggal)     { toast('Tanggal kegiatan harus diisi','error'); return false; }
    if (selected.size===0) { toast('Pilih minimal 1 nama','error'); return false; }
    return true;
  };

  const handleSubmit = async () => {
    if (!validate()) return;

    // Cek barang jika Peminjaman
    if (form.jenisSurat === 'Peminjaman') {
      try {
        const b = await api.getBarang(form.noSurat);
        if (!b.data?.length) {
          const ok = window.confirm('Belum ada barang pinjaman. Tetap buat surat?');
          if (!ok) { setShowBarang(true); return; }
        }
      } catch(e) {}
    }

    setLoading(true);
    try {
      const [batchRes] = await Promise.all([api.getNextBatch()]);
      const idBatch = batchRes.next;

      const selectedGuru = guru.filter(g => selected.has(g.ID_Guru));
      const isSekaligus  = form.jenisMailing === 'Sekaligus';

      // Untuk Sekaligus: semua pakai No_Surat yang sama
      // Untuk Perseorangan: No_Surat bertambah tiap orang
      const rows = selectedGuru.map((g, i) => ({
        No_Surat:         isSekaligus ? form.noSurat : Number(form.noSurat) + i,
        Tanggal_Hijriah:  form.tglHijriah,
        Tanggal_Romawi:   form.tglRomawi,
        Hal:              form.hal,
        Nama:             g.Nama,
        Ket:              form.ket,
        Kamar_Bagian:     g.Kamar_Bagian,
        Prodi:            g.Prodi,
        Semester:         g.Semester,
        Tahun_Pengabdian: g.Tahun_Pengabdian,
        Hari:             form.hari,
        Tanggal:          form.tanggal,
        Tempat:           form.tempat,
        Waktu:            form.waktu,
        Acara:            form.acara,
        Jenis_Surat:      form.jenisSurat,
        Jenis_Mailing:    form.jenisMailing,
        ID_Batch:         idBatch,
      }));

      await api.insertSurat(rows);
      toast('Mailing berhasil dibuat!','success');
      setSelected(new Set());
      setForm({ ...EMPTY_FORM });
      // refresh no surat
      const n = await api.getNextNoSurat();
      setForm(f => ({ ...f, noSurat: n.next }));
      onDone(idBatch);
    } catch(e) {
      toast('Gagal: ' + e.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fade-in">
      {/* ── Jenis Surat + Mailing ── */}
      <div className="card" style={{ marginBottom:16 }}>
        <div className="section-title">Jenis Surat</div>
        <div className="grid-2">
          <div>
            <label>Jenis Surat</label>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
              {JENIS_SURAT.map(j => (
                <button key={j} className="btn"
                  onClick={() => set('jenisSurat', j)}
                  style={{
                    background: form.jenisSurat===j ? 'var(--accent)' : 'var(--accent-soft)',
                    color:      form.jenisSurat===j ? '#fff' : 'var(--accent)',
                    flex:1,
                  }}>
                  {j}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label>Mode Mailing</label>
            <div style={{ display:'flex', gap:8 }}>
              {JENIS_MAILING.map(j => (
                <button key={j} className="btn"
                  onClick={() => set('jenisMailing', j)}
                  style={{
                    background: form.jenisMailing===j ? 'var(--accent2)' : '#EDF7F1',
                    color:      form.jenisMailing===j ? '#fff' : 'var(--accent2)',
                    flex:1,
                  }}>
                  {j==='Perseorangan' ? '👤 Perseorangan' : '👥 Sekaligus'}
                </button>
              ))}
            </div>
            <div style={{ fontSize:11, marginTop:6, opacity:.6, lineHeight:1.5 }}>
              {form.jenisMailing==='Perseorangan'
                ? 'Satu surat per orang, nomor surat bertambah tiap orang'
                : 'Satu surat + lampiran daftar nama semua orang terpilih'}
            </div>
          </div>
        </div>
      </div>

      {/* ── Data Header Surat ── */}
      <div className="card" style={{ marginBottom:16 }}>
        <div className="section-title">Data Surat</div>
        <div className="grid-3" style={{ marginBottom:14 }}>
          <div>
            <label>Nomor Surat</label>
            <input type="number" value={form.noSurat}
              onChange={e => set('noSurat', e.target.value)} />
          </div>
          <div>
            <label>Tanggal Hijriah</label>
            <input placeholder="1 Rajab 1446 H" value={form.tglHijriah}
              onChange={e => set('tglHijriah', e.target.value)} />
          </div>
          <div>
            <label>Tanggal Romawi</label>
            <input placeholder="I/2025" value={form.tglRomawi}
              onChange={e => set('tglRomawi', e.target.value)} />
          </div>
        </div>
        <div className="grid-2" style={{ marginBottom:14 }}>
          <div>
            <label>Perihal (Hal)</label>
            <input placeholder="Permohonan Izin Kegiatan" value={form.hal}
              onChange={e => set('hal', e.target.value)} />
          </div>
          <div>
            <label>Keterangan (Ket)</label>
            <input placeholder="Al Ustadz ..., S.Pd." value={form.ket}
              onChange={e => set('ket', e.target.value)} />
          </div>
        </div>
        <div className="grid-3" style={{ marginBottom:14 }}>
          <div>
            <label>Tanggal Kegiatan</label>
            <input type="date" value={form.tanggal}
              onChange={e => set('tanggal', e.target.value)} />
          </div>
          <div>
            <label>Hari</label>
            <select value={form.hari} onChange={e => set('hari', e.target.value)}>
              <option value="">-- Pilih --</option>
              {HARI.map(h => <option key={h}>{h}</option>)}
            </select>
          </div>
          <div>
            <label>Waktu</label>
            <input placeholder="08.00 WIB" value={form.waktu}
              onChange={e => set('waktu', e.target.value)} />
          </div>
        </div>
        <div className="grid-2">
          <div>
            <label>Tempat</label>
            <input placeholder="Aula Pondok" value={form.tempat}
              onChange={e => set('tempat', e.target.value)} />
          </div>
          <div>
            <label>Acara</label>
            <input placeholder="Rapat Kepanitiaan ..." value={form.acara}
              onChange={e => set('acara', e.target.value)} />
          </div>
        </div>

        {/* Tombol barang jika Peminjaman */}
        {form.jenisSurat === 'Peminjaman' && (
          <div style={{ marginTop:16, padding:'12px 16px', background:'#FFFBEB',
                        borderRadius:8, border:'1px solid #FDE68A', display:'flex',
                        alignItems:'center', justifyContent:'space-between' }}>
            <div style={{ fontSize:13 }}>
              <strong>📦 Peminjaman</strong> — Input daftar barang sebelum buat surat
            </div>
            <button className="btn btn-secondary" onClick={handleOpenBarang}>
              Kelola Barang
            </button>
          </div>
        )}
      </div>

      {/* ── Checklist Guru ── */}
      <div className="card" style={{ marginBottom:16 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12 }}>
          <div className="section-title" style={{ margin:0, border:'none', padding:0 }}>
            Pilih Nama ({selected.size} dipilih)
          </div>
          <div style={{ display:'flex', gap:8, alignItems:'center' }}>
            <input placeholder="🔍 Cari nama / bagian..." value={search}
              onChange={e => setSearch(e.target.value)}
              style={{ width:200, fontSize:12 }} />
            <button className="btn btn-ghost" style={{ fontSize:12, whiteSpace:'nowrap' }}
              onClick={toggleAll}>
              {selected.size===filteredGuru.length && filteredGuru.length>0 ? 'Batal Semua' : 'Pilih Semua'}
            </button>
          </div>
        </div>

        {loadingGuru ? (
          <div style={{ padding:40, textAlign:'center', opacity:.5 }}>Memuat data guru...</div>
        ) : filteredGuru.length === 0 ? (
          <div style={{ padding:40, textAlign:'center', opacity:.5 }}>
            Tidak ada data guru. Tambahkan di menu Master Guru.
          </div>
        ) : (
          <div style={{ maxHeight:320, overflowY:'auto', border:'1px solid var(--border)', borderRadius:8 }}>
            <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
              <thead>
                <tr style={{ background:'var(--bg)', position:'sticky', top:0 }}>
                  <th style={{ padding:'8px 12px', textAlign:'left', fontWeight:600, fontSize:12, width:40 }}>#</th>
                  <th style={{ padding:'8px 12px', textAlign:'left', fontWeight:600, fontSize:12 }}>Nama</th>
                  <th style={{ padding:'8px 12px', textAlign:'left', fontWeight:600, fontSize:12 }}>Kamar/Bagian</th>
                  <th style={{ padding:'8px 12px', textAlign:'left', fontWeight:600, fontSize:12 }}>Prodi</th>
                  <th style={{ padding:'8px 12px', textAlign:'left', fontWeight:600, fontSize:12 }}>Semester</th>
                  <th style={{ padding:'8px 12px', textAlign:'left', fontWeight:600, fontSize:12 }}>Thn Pengabdian</th>
                </tr>
              </thead>
              <tbody>
                {filteredGuru.map(g => (
                  <tr key={g.ID_Guru}
                    onClick={() => toggleGuru(g.ID_Guru)}
                    style={{
                      cursor:'pointer',
                      background: selected.has(g.ID_Guru) ? 'var(--accent-soft)' : 'transparent',
                      borderTop:'1px solid var(--border)',
                      transition:'background .1s',
                    }}>
                    <td style={{ padding:'8px 12px' }}>
                      <div style={{
                        width:18, height:18, borderRadius:4,
                        border:`2px solid ${selected.has(g.ID_Guru) ? 'var(--accent)' : 'var(--border)'}`,
                        background: selected.has(g.ID_Guru) ? 'var(--accent)' : 'transparent',
                        display:'flex', alignItems:'center', justifyContent:'center',
                        fontSize:11, color:'#fff',
                      }}>
                        {selected.has(g.ID_Guru) && '✓'}
                      </div>
                    </td>
                    <td style={{ padding:'8px 12px', fontWeight: selected.has(g.ID_Guru) ? 600 : 400 }}>
                      {g.Nama}
                    </td>
                    <td style={{ padding:'8px 12px', opacity:.7 }}>{g.Kamar_Bagian}</td>
                    <td style={{ padding:'8px 12px', opacity:.7 }}>{g.Prodi}</td>
                    <td style={{ padding:'8px 12px', opacity:.7 }}>{g.Semester}</td>
                    <td style={{ padding:'8px 12px', opacity:.7 }}>{g.Tahun_Pengabdian}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ── Tombol Submit ── */}
      <div style={{ display:'flex', justifyContent:'flex-end', gap:12 }}>
        <button className="btn btn-ghost"
          onClick={() => { setForm({...EMPTY_FORM}); setSelected(new Set()); }}>
          Reset
        </button>
        <button className="btn btn-primary" onClick={handleSubmit} disabled={loading}
          style={{ minWidth:160, justifyContent:'center' }}>
          {loading ? '⏳ Menyimpan...' : `✉ Buat ${form.jenisSurat} (${selected.size} orang)`}
        </button>
      </div>

      {/* ── Modal Barang ── */}
      {showBarang && (
        <BarangModal
          noSurat={noSuratBarang}
          onClose={() => setShowBarang(false)}
        />
      )}
    </div>
  );
}
