// ================================================================
// APPS SCRIPT BACKEND — Surat Kepanitiaan
// Deploy sebagai Web App:
//   Execute as: Me
//   Who has access: Anyone
//
// Sheet yang dibutuhkan (nama harus SAMA PERSIS):
//   1. MasterGuru
//   2. SuratKepanitiaan
//   3. BarangPinjaman
//   4. Seting
// ================================================================

const SHEET_GURU    = 'MasterGuru';
const SHEET_SURAT   = 'SuratKepanitiaan';
const SHEET_BARANG  = 'BarangPinjaman';
const SHEET_SETING  = 'Seting';

// ================================================================
// ROUTER UTAMA
// ================================================================
function doGet(e) {
  const action = e.parameter.action;
  let result;
  try {
    switch (action) {
      case 'getGuru':        result = getGuru();           break;
      case 'getSurat':       result = getSurat(e);         break;
      case 'getBarang':      result = getBarang(e);        break;
      case 'getSeting':      result = getSeting();         break;
      case 'getNextNoSurat': result = getNextNoSurat();    break;
      case 'getNextBatch':   result = getNextBatch();      break;
      default: result = { error: 'Action tidak dikenal: ' + action };
    }
  } catch (err) {
    result = { error: err.message };
  }
  return jsonResponse(result);
}

function doPost(e) {
  const payload = JSON.parse(e.postData.contents);
  const action  = payload.action;
  let result;
  try {
    switch (action) {
      case 'insertSurat':   result = insertSurat(payload);   break;
      case 'insertBarang':  result = insertBarang(payload);  break;
      case 'deleteBarang':  result = deleteBarang(payload);  break;
      case 'deleteBatch':   result = deleteBatch(payload);   break;
      case 'saveSeting':    result = saveSeting(payload);    break;
      case 'updateGuru':    result = updateGuru(payload);    break;
      case 'addGuru':       result = addGuru(payload);       break;
      case 'deleteGuru':    result = deleteGuru(payload);    break;
      default: result = { error: 'Action tidak dikenal: ' + action };
    }
  } catch (err) {
    result = { error: err.message };
  }
  return jsonResponse(result);
}

function jsonResponse(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

// ================================================================
// HELPER: Ambil sheet
// ================================================================
function getSheet(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = createSheet(name);
  return sheet;
}

// ================================================================
// HELPER: Buat sheet + header otomatis jika belum ada
// ================================================================
function createSheet(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.insertSheet(name);
  const headers = {
    [SHEET_GURU]: [
      'ID_Guru','Nama','Tahun_Pengabdian','Kamar_Bagian','Prodi','Semester'
    ],
    [SHEET_SURAT]: [
      'ID_Surat','No_Surat','Tanggal_Hijriah','Tanggal_Romawi','Hal',
      'Nama','Ket','Kamar_Bagian','Prodi','Semester','Tahun_Pengabdian',
      'Hari','Tanggal','Tempat','Waktu','Acara',
      'Jenis_Surat','Jenis_Mailing','ID_Batch','Tanggal_Dibuat'
    ],
    [SHEET_BARANG]: [
      'ID_Peminjaman','No_Surat','Nama_Barang','Jumlah_Barang','Satuan','Keterangan'
    ],
    [SHEET_SETING]: ['Kode','Nama_Seting','Nilai']
  };
  if (headers[name]) {
    sheet.appendRow(headers[name]);
    sheet.getRange(1, 1, 1, headers[name].length)
         .setFontWeight('bold')
         .setBackground('#f3f4f6');
  }
  // Seed Seting defaults
  if (name === SHEET_SETING) {
    sheet.appendRow([0, 'Nama Instansi', 'Pondok Modern Darussalam Gontor']);
    sheet.appendRow([1, 'Alamat',        'Ponorogo, Jawa Timur']);
    sheet.appendRow([2, 'TTD Nama',      'KH. ...']);
    sheet.appendRow([3, 'TTD Jabatan',   'Direktur KMI']);
  }
  return sheet;
}

// ================================================================
// MASTER GURU
// ================================================================
function getGuru() {
  const sheet = getSheet(SHEET_GURU);
  const data  = sheet.getDataRange().getValues();
  if (data.length <= 1) return { data: [] };
  const headers = data[0];
  const rows = data.slice(1).map((r, i) => {
    const obj = {};
    headers.forEach((h, j) => obj[h] = r[j]);
    obj._row = i + 2; // baris di sheet (1-indexed, +1 untuk header)
    return obj;
  }).filter(r => r.ID_Guru !== '');
  return { data: rows };
}

function addGuru(payload) {
  const sheet = getSheet(SHEET_GURU);
  const data  = sheet.getDataRange().getValues();
  const ids   = data.slice(1).map(r => Number(r[0])).filter(Boolean);
  const newId = ids.length > 0 ? Math.max(...ids) + 1 : 1;
  sheet.appendRow([
    newId,
    payload.Nama             || '',
    payload.Tahun_Pengabdian || '',
    payload.Kamar_Bagian     || '',
    payload.Prodi            || '',
    payload.Semester         || ''
  ]);
  return { success: true, id: newId };
}

function updateGuru(payload) {
  const sheet = getSheet(SHEET_GURU);
  const row   = payload._row;
  sheet.getRange(row, 1, 1, 6).setValues([[
    payload.ID_Guru,
    payload.Nama             || '',
    payload.Tahun_Pengabdian || '',
    payload.Kamar_Bagian     || '',
    payload.Prodi            || '',
    payload.Semester         || ''
  ]]);
  return { success: true };
}

function deleteGuru(payload) {
  const sheet = getSheet(SHEET_GURU);
  sheet.deleteRow(payload._row);
  return { success: true };
}

// ================================================================
// SURAT KEPANITIAAN
// ================================================================
function getSurat(e) {
  const sheet   = getSheet(SHEET_SURAT);
  const data    = sheet.getDataRange().getValues();
  if (data.length <= 1) return { data: [] };
  const headers = data[0];
  let rows = data.slice(1).map((r, i) => {
    const obj = {};
    headers.forEach((h, j) => obj[h] = r[j]);
    obj._row = i + 2;
    return obj;
  }).filter(r => r.ID_Surat !== '');

  // Filter by batch jika ada
  if (e && e.parameter && e.parameter.batch) {
    const batch = Number(e.parameter.batch);
    rows = rows.filter(r => Number(r.ID_Batch) === batch);
  }
  return { data: rows };
}

function insertSurat(payload) {
  const sheet   = getSheet(SHEET_SURAT);
  const data    = sheet.getDataRange().getValues();
  const ids     = data.slice(1).map(r => Number(r[0])).filter(Boolean);
  let   idSurat = ids.length > 0 ? Math.max(...ids) + 1 : 1;

  const rows = payload.rows; // array of row objects
  rows.forEach(r => {
    sheet.appendRow([
      idSurat++,
      r.No_Surat,
      r.Tanggal_Hijriah  || '',
      r.Tanggal_Romawi   || '',
      r.Hal              || '',
      r.Nama             || '',
      r.Ket              || '',
      r.Kamar_Bagian     || '',
      r.Prodi            || '',
      r.Semester         || '',
      r.Tahun_Pengabdian || '',
      r.Hari             || '',
      r.Tanggal          || '',
      r.Tempat           || '',
      r.Waktu            || '',
      r.Acara            || '',
      r.Jenis_Surat      || '',
      r.Jenis_Mailing    || '',
      r.ID_Batch,
      new Date().toISOString()
    ]);
  });
  return { success: true, count: rows.length };
}

function deleteBatch(payload) {
  const sheet   = getSheet(SHEET_SURAT);
  const data    = sheet.getDataRange().getValues();
  const headers = data[0];
  const batchIdx = headers.indexOf('ID_Batch');

  // Kumpulkan No_Surat yang akan dihapus juga barangnya
  const noSuratIdx = headers.indexOf('No_Surat');
  const noSuratSet = new Set();

  // Hapus dari bawah supaya index tidak bergeser
  for (let i = data.length - 1; i >= 1; i--) {
    if (Number(data[i][batchIdx]) === Number(payload.batch)) {
      noSuratSet.add(data[i][noSuratIdx]);
      sheet.deleteRow(i + 1);
    }
  }

  // Hapus barang terkait
  noSuratSet.forEach(ns => {
    deleteBarang({ No_Surat: ns, _all: true });
  });

  return { success: true };
}

function getNextNoSurat() {
  const sheet = getSheet(SHEET_SURAT);
  const data  = sheet.getDataRange().getValues();
  const nos   = data.slice(1).map(r => Number(r[1])).filter(Boolean);
  return { next: nos.length > 0 ? Math.max(...nos) + 1 : 1 };
}

function getNextBatch() {
  const sheet = getSheet(SHEET_SURAT);
  const data  = sheet.getDataRange().getValues();
  const headers = data[0];
  const bIdx  = headers.indexOf('ID_Batch');
  const batches = data.slice(1).map(r => Number(r[bIdx])).filter(Boolean);
  return { next: batches.length > 0 ? Math.max(...batches) + 1 : 1 };
}

// ================================================================
// BARANG PINJAMAN
// ================================================================
function getBarang(e) {
  const sheet   = getSheet(SHEET_BARANG);
  const data    = sheet.getDataRange().getValues();
  if (data.length <= 1) return { data: [] };
  const headers = data[0];
  let rows = data.slice(1).map((r, i) => {
    const obj = {};
    headers.forEach((h, j) => obj[h] = r[j]);
    obj._row = i + 2;
    return obj;
  }).filter(r => r.ID_Peminjaman !== '');

  if (e && e.parameter && e.parameter.noSurat) {
    rows = rows.filter(r => String(r.No_Surat) === String(e.parameter.noSurat));
  }
  return { data: rows };
}

function insertBarang(payload) {
  const sheet = getSheet(SHEET_BARANG);
  const data  = sheet.getDataRange().getValues();
  const ids   = data.slice(1).map(r => Number(r[0])).filter(Boolean);
  let   idB   = ids.length > 0 ? Math.max(...ids) + 1 : 1;

  const items = payload.items;
  items.forEach(item => {
    sheet.appendRow([
      idB++,
      item.No_Surat,
      item.Nama_Barang    || '',
      item.Jumlah_Barang  || 0,
      item.Satuan         || '',
      item.Keterangan     || ''
    ]);
  });
  return { success: true };
}

function deleteBarang(payload) {
  const sheet   = getSheet(SHEET_BARANG);
  const data    = sheet.getDataRange().getValues();
  const headers = data[0];
  const nsIdx   = headers.indexOf('No_Surat');
  const idIdx   = headers.indexOf('ID_Peminjaman');

  for (let i = data.length - 1; i >= 1; i--) {
    if (payload._all && String(data[i][nsIdx]) === String(payload.No_Surat)) {
      sheet.deleteRow(i + 1);
    } else if (!payload._all && Number(data[i][idIdx]) === Number(payload.ID_Peminjaman)) {
      sheet.deleteRow(i + 1);
      break;
    }
  }
  return { success: true };
}

// ================================================================
// SETING
// ================================================================
function getSeting() {
  const sheet = getSheet(SHEET_SETING);
  const data  = sheet.getDataRange().getValues();
  if (data.length <= 1) return { data: {} };
  const result = {};
  data.slice(1).forEach(r => {
    result[r[0]] = { nama: r[1], nilai: r[2] };
  });
  return { data: result };
}

function saveSeting(payload) {
  const sheet   = getSheet(SHEET_SETING);
  const data    = sheet.getDataRange().getValues();
  payload.items.forEach(item => {
    let found = false;
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][0]) === String(item.Kode)) {
        sheet.getRange(i + 1, 3).setValue(item.Nilai);
        found = true;
        break;
      }
    }
    if (!found) {
      sheet.appendRow([item.Kode, item.Nama, item.Nilai]);
    }
  });
  return { success: true };
}
